import os

def welcome():
    print("Welcome to the Caesar Cipher")
    print("This program encrypts and decrypts text with the Caesar Cipher.")


def enter_message():
    while True:
        try:
            mode = input("Would you like to encrypt (e) or decrypt (d)?: ").lower()
            if mode == "e" or mode == "d":
                break
            else:
                print("Invalid mode, please enter 'encrypt' (e) or 'decrypt' (d).")
        except KeyboardInterrupt:
            print("\nProgram interrupted by user.")
            raise

    while True:
        try:
            message = input(f"What message would you like to {mode}?: ")
            shift_num = int(input(f"What is the shift number?: "))
            break
        except ValueError:
            print("Invalid input! Please enter a valid shift number.")
        except KeyboardInterrupt:
            print("\nProgram interrupted by user.")
            raise

    return mode, message, shift_num


def encrypt(message, shift):
    cipher_text = ""
    for char in message:
        if char.isalpha():
            char_code = ord(char.upper()) - 65
            new_code = (char_code + shift) % 26
            cipher_text += chr(new_code + 65)
        else:
            cipher_text += char
    return cipher_text


def decrypt(message, shift):
    plain_text = ""
    for char in message:
        if char.isalpha():
            char_code = ord(char.upper()) - 65
            new_code = (char_code - shift) % 26
            plain_text += chr(new_code + 65)
        else:
            plain_text += char
    return plain_text


def process_file(filename, mode, shift):
    messages = []
    try:
        with open(filename, 'r') as file:
            for line in file:
                line = line.strip()
                if mode == 'e':
                    encrypted = encrypt(line, shift)
                    messages.append(encrypted)
                elif mode == 'd':
                    decrypted = decrypt(line, shift)
                    messages.append(decrypted)
    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print(f"An error occurred while processing the file: {str(e)}")
    return messages


def is_file(filename):
    return os.path.isfile(filename)


def write_messages(messages):
    try:
        with open('results.txt', 'w') as file:
            for message in messages:
                file.write(message + '\n')
    except Exception as e:
        print(f"An error occurred while writing messages to file: {str(e)}")


def message_or_file():
    while True:
        mode = input("Would you like to encrypt (e) or decrypt (d)?: ").lower()
        if mode == 'e' or mode == 'd':
            break
        else:
            print("Invalid mode. Please enter 'e' or 'd'.")

    while True:
        source = input("Would you like to read from a file (f) or the console (c)?: ").lower()
        if source == 'f':
            while True:
                filename = input("Enter a filename: ")
                if is_file(filename):
                    break
                else:
                    print("Invalid filename. Please enter an existing file.")
            message = None
            break
        elif source == 'c':
            message = input("What message would you like to process?: ")
            filename = None
            break
        else:
            print("Invalid input. Please enter 'f' or 'c'.")

    while True:
        try:
            shift_num = int(input("What is the shift number?: "))
            break
        except ValueError:
            print("Invalid input! Please enter a valid shift number.")
        except KeyboardInterrupt:
            print("\nProgram interrupted by user.")
            raise

    return mode, message, filename, shift_num


def main():
    welcome()
    while True:
        try:
            mode, message, filename, shift = message_or_file()
            if filename:
                messages = process_file(filename, mode, shift)
                print("Encrypted/Decrypted messages:")
                for msg in messages:
                    print(msg)
                write_messages(messages)
            elif message:
                if mode == 'e':
                    output = encrypt(message, shift)
                elif mode == 'd':
                    output = decrypt(message, shift)
                print(output.upper())
            while True:
                choice = input("Would you like to encrypt or decrypt another message? (y/n): ").lower()
                if choice == 'y' or choice == 'n':
                    break
                else:
                    print("Invalid input. Please enter 'y' or 'n'.")
            if choice == 'n':
                print("Thanks for using the program, goodbye!")
                break
        except KeyboardInterrupt:
            print("\nProgram interrupted by user.")
            break

if __name__ == "__main__":
    main()