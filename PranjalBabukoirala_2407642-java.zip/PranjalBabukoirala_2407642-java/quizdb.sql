-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2025 at 11:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `competitordb`
--

CREATE TABLE `competitordb` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `level` varchar(50) NOT NULL,
  `score1` int(11) DEFAULT NULL,
  `score2` int(11) DEFAULT NULL,
  `score3` int(11) DEFAULT NULL,
  `score4` int(11) DEFAULT NULL,
  `score5` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `competitordb`
--

INSERT INTO `competitordb` (`id`, `username`, `level`, `score1`, `score2`, `score3`, `score4`, `score5`) VALUES
(1, 'prnskn', 'Beginner', 5, 4, NULL, NULL, NULL),
(2, 'pranjal', 'Intermediate', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `correct_answer` varchar(255) NOT NULL,
  `option1` varchar(255) NOT NULL,
  `option2` varchar(255) NOT NULL,
  `option3` varchar(255) NOT NULL,
  `difficulty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `correct_answer`, `option1`, `option2`, `option3`, `difficulty`) VALUES
(1, '2+2', '4', '2', '1', '3', 'Beginner'),
(2, '33*2', '66', '85', '77', '565', 'Beginner'),
(3, 'color of sky', 'blue', 'white', 'red', 'black', 'Beginner'),
(4, 'prime minister of nepal', 'kp oli', 'ram', 'rajesh hamal', 'durga', 'Beginner'),
(5, 'What is 5 + 3?', '8', '6', '7', '9', 'Beginner'),
(6, 'What is the capital of France?', 'Paris', 'London', 'Berlin', 'Madrid', 'Beginner'),
(7, 'What is 10 / 2?', '5', '4', '6', '3', 'Beginner'),
(8, 'What color is an apple?', 'Red', 'Blue', 'Green', 'Yellow', 'Beginner'),
(9, 'Which animal is known as the King of the Jungle?', 'Lion', 'Tiger', 'Elephant', 'Giraffe', 'Beginner'),
(10, 'What is 7 * 6?', '42', '36', '48', '40', 'Beginner'),
(11, 'Which planet is closest to the sun?', 'Mercury', 'Venus', 'Earth', 'Mars', 'Beginner'),
(12, 'How many days are there in a week?', '7', '5', '6', '8', 'Beginner'),
(13, 'What is the boiling point of water in Celsius?', '100', '90', '80', '120', 'Beginner'),
(14, 'What is the opposite of hot?', 'Cold', 'Warm', 'Cool', 'Boiling', 'Beginner'),
(15, 'What is the square root of 144?', '12', '10', '14', '16', 'Intermediate'),
(16, 'Which continent has the most countries?', 'Africa', 'Asia', 'Europe', 'North America', 'Intermediate'),
(17, 'What is 25% of 200?', '50', '40', '60', '75', 'Intermediate'),
(18, 'Which gas do plants absorb from the atmosphere?', 'Carbon Dioxide', 'Oxygen', 'Nitrogen', 'Hydrogen', 'Intermediate'),
(19, 'Who developed the theory of relativity?', 'Einstein', 'Newton', 'Galileo', 'Tesla', 'Intermediate'),
(20, 'Which is the longest river in the world?', 'Nile', 'Amazon', 'Yangtze', 'Mississippi', 'Intermediate'),
(21, 'What is the capital of Japan?', 'Tokyo', 'Seoul', 'Beijing', 'Bangkok', 'Intermediate'),
(22, 'What is the chemical symbol for gold?', 'Au', 'Ag', 'Fe', 'Hg', 'Intermediate'),
(23, 'How many sides does a hexagon have?', '6', '5', '7', '8', 'Intermediate'),
(24, 'What is the powerhouse of the cell?', 'Mitochondria', 'Nucleus', 'Ribosome', 'Cytoplasm', 'Intermediate'),
(25, 'What is the derivative of sin(x)?', 'cos(x)', '-sin(x)', 'tan(x)', 'sec(x)', 'Advanced'),
(26, 'Which sorting algorithm has the worst-case time complexity of O(n^2)?', 'Bubble Sort', 'Merge Sort', 'Quick Sort', 'Heap Sort', 'Advanced'),
(27, 'What does HTTP stand for?', 'HyperText Transfer Protocol', 'Hyper Transfer Text Process', 'High Transmission Text Path', 'Hyperlink Transmission Protocol', 'Advanced'),
(28, 'Who is known as the father of computers?', 'Charles Babbage', 'Alan Turing', 'John von Neumann', 'Bill Gates', 'Advanced'),
(29, 'Which layer of the OSI model handles encryption?', 'Presentation', 'Network', 'Transport', 'Application', 'Advanced'),
(30, 'Which programming language is primarily used for developing Android apps?', 'Java', 'Python', 'C++', 'Swift', 'Advanced'),
(31, 'What is the Big-O notation for binary search?', 'O(log n)', 'O(n)', 'O(n^2)', 'O(1)', 'Advanced'),
(32, 'Which SQL command is used to remove all records from a table?', 'DELETE', 'DROP', 'TRUNCATE', 'REMOVE', 'Advanced'),
(33, 'What is the primary purpose of DNS?', 'Translate domain names to IP addresses', 'Secure websites', 'Store web pages', 'Optimize network speed', 'Advanced'),
(34, 'Which data structure follows the LIFO principle?', 'Stack', 'Queue', 'Linked List', 'Heap', 'Advanced');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `competitordb`
--
ALTER TABLE `competitordb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `competitordb`
--
ALTER TABLE `competitordb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
