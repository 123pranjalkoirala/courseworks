package try1;
import java.util.ArrayList;

public class PlayerList {
    private ArrayList<Player> players;

    public PlayerList() {
        players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void sortByScore() {
        players.sort((p1, p2) -> Integer.compare(p2.getScore(), p1.getScore())); // Sort by score
    }
}