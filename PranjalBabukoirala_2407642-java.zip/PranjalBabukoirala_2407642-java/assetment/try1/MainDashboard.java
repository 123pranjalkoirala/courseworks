package try1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class MainDashboard {
    private JFrame frame;
    private String username;
    private String level;

    public MainDashboard(String username, String level) {
        this.username = username;
        this.level = level;
        frame = new JFrame("Main Dashboard");
        frame.setSize(400, 300);
        frame.getContentPane().setBackground(Color.decode("#121212")); // Jet Black
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(5, 1)); // Adjusted to accommodate the logout button

        JLabel welcomeLabel = new JLabel("Welcome, " + username + "!", SwingConstants.CENTER);
        welcomeLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.add(welcomeLabel);

        JButton startQuizButton = new JButton("Start Quiz");
        startQuizButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        startQuizButton.setForeground(Color.WHITE);
        startQuizButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new QuizGame(username, level); // Start the quiz
                frame.dispose(); // Close the dashboard
            }
        });
        frame.add(startQuizButton);

        JButton viewLeaderboardButton = new JButton("View Leaderboard");
        viewLeaderboardButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        viewLeaderboardButton.setForeground(Color.WHITE);
        viewLeaderboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Leaderboard(); // Show leaderboard
            }
        });
        frame.add(viewLeaderboardButton);

        JButton viewSelfDetailsButton = new JButton("View Self Details");
        viewSelfDetailsButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        viewSelfDetailsButton.setForeground(Color.WHITE);
        viewSelfDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displaySelfDetails(); // Show self details
            }
        });
        frame.add(viewSelfDetailsButton);

        // Logout Button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(Color.decode("#FF3B30")); // Crimson Red
        logoutButton.setForeground(Color.WHITE);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the dashboard
                new Login(); // Open the login screen
            }
        });
        frame.add(logoutButton);

        frame.setVisible(true);
        
    }

    private void displaySelfDetails() {
    	CompetitorList competitorList = new CompetitorList();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT * FROM CompetitorDB";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String level = rs.getString("level");
                Competitor competitor = new Competitor(id, username, level,rs.getInt("score1"),rs.getInt("score2"),rs.getInt("score3"),rs.getInt("score4"),rs.getInt("score5"));
                competitorList.addCompetitor(competitor);
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Fetch the competitor's details using the CompetitorList
        Competitor competitor = competitorList.getCompetitor(username,level); // Get the competitor by username

        if (competitor != null) {
            // Generate the report using the Competitor's method
            String report = competitor.generateReport();
            JOptionPane.showMessageDialog(frame, report, "Self Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Competitor not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}