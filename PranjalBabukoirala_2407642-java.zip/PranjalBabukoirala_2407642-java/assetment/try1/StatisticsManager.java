package try1;

import java.sql.*;

public class StatisticsManager {
    private Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void savePlayerScore(String playerName, int score) {
        String sql = "INSERT INTO player_scores (name, score) VALUES (?, ?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, playerName);
            pstmt.setInt(2, score);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getTotalPlayers() {
        int total = 0;
        String sql = "SELECT COUNT(*) FROM player_scores";
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }

    public int getHighestScore() {
        int highest = 0;
        String sql = "SELECT MAX(score) FROM player_scores";
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                highest = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return highest;
    }
}