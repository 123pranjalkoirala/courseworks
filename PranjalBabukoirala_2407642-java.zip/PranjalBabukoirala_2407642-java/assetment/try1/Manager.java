package try1;
import java.sql.*;

public class Manager {
    private Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void addQuestion(String question, String correctAnswer, String[] options) {
        String sql = "INSERT INTO questions (question, correct_answer, option1, option2, option3) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, question);
            pstmt.setString(2, correctAnswer);
            pstmt.setString(3, options[0]);
            pstmt.setString(4, options[1]);
            pstmt.setString(5, options[2]);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteQuestion(int id) {
        String sql = "DELETE FROM questions WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}