package try1;

import java.util.ArrayList;

public class Question {
    private String question; // The question text
    private String correctAnswer; // The correct answer (which will be option4)
    private ArrayList<String> options; // The answer options
    private String difficulty; // The difficulty level

    public Question(String question, String correctAnswer, ArrayList<String> options, String difficulty) {
        this.question = question; // Initialize question
        this.correctAnswer = correctAnswer; // Initialize correct answer
        this.options = options; // Initialize options
        this.difficulty = difficulty; // Initialize difficulty
    }

    public String getQuestion() {
        return question; // Getter for question
    }

    public String getCorrectAnswer() {
        return correctAnswer; // Getter for correct answer
    }

    public ArrayList<String> getOptions() {
        return options; // Getter for options
    }

    public String getDifficulty() {
        return difficulty; // Getter for difficulty
    }
}