package try1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static void main(String[] args) {
        createDatabaseAndTables();
        new Login();
        showConsoleMenu(); // Show the console menu
    }

    private static void createDatabaseAndTables() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {

            // Create database if it does not exist
            String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS quizdb";
            stmt.executeUpdate(createDatabaseSQL);

            // Use the created database
            stmt.execute("USE quizdb");

            // Create questions table if it does not exist
            String createQuestionsTableSQL = "CREATE TABLE IF NOT EXISTS questions (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "question TEXT NOT NULL," +
                    "correct_answer VARCHAR(255) NOT NULL," +
                    "option1 VARCHAR(255) NOT NULL," +
                    "option2 VARCHAR(255) NOT NULL," +
                    "option3 VARCHAR(255) NOT NULL," +
                    "difficulty VARCHAR(50) NOT NULL" +
                    ")";
            stmt.executeUpdate(createQuestionsTableSQL);

            // Create CompetitorDB table with level attribute and NULL scores
            String createCompetitorTableSQL = "CREATE TABLE IF NOT EXISTS CompetitorDB (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "username VARCHAR(255) NOT NULL," +
                    "level VARCHAR(50) NOT NULL," +
                    "score1 INT DEFAULT NULL," +
                    "score2 INT DEFAULT NULL," +
                    "score3 INT DEFAULT NULL," +
                    "score4 INT DEFAULT NULL," +
                    "score5 INT DEFAULT NULL" +
                    ")";
            stmt.executeUpdate(createCompetitorTableSQL);

            System.out.println("Database and tables created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void showConsoleMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Competitor Management System");
            System.out.println("1. Generate Full Report");
            System.out.println("2. Display Top Performer");
            System.out.println("3. Generate Statistics");
            System.out.println("4. Search Competitor by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    generateFullReport();
                    break;
                case 2:
                    displayTopPerformer();
                    break;
                case 3:
                    generateStatistics();
                    break;
                case 4:
                    searchCompetitorById(scanner);
                    break;
                case 5:
                    System.out.println("Exiting the application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void generateFullReport() {
        // Logic to generate and display the full report
        System.out.println("Generating full report...");
        // You can implement the report generation logic here
        // For example, you can fetch all competitors and their scores from the database
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT * FROM CompetitorDB";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String level = rs.getString("level");
                int score1 = rs.getInt("score1");
                int score2 = rs.getInt("score2");
                int score3 = rs.getInt("score3");
                int score4 = rs.getInt("score4");
                int score5 = rs.getInt("score5");
                System.out.println("ID: " + id + ", Username: " + username + ", Level: " + level +
                        ", Scores: [" + score1 + ", " + score2 + ", " + score3 + ", " + score4 + ", " + score5 + "]");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void displayTopPerformer() {
        // Logic to display the top performer
        System.out.println("Displaying top performer...");
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT username, level, (COALESCE(score1, 0) + COALESCE(score2, 0) + COALESCE(score3, 0) + COALESCE(score4, 0) + COALESCE(score5, 0)) AS total " +
                         "FROM CompetitorDB ORDER BY total DESC LIMIT 1";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                String username = rs.getString("username");
                String level = rs.getString("level");
                int totalScore = rs.getInt("total");
                System.out.println("Top Performer: Username: " + username + ", Level: " + level + ", Total Score: " + totalScore);
            } else {
                System.out.println("No competitors found.");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void generateStatistics() {
        // Logic to generate and display statistics
        System.out.println("Generating statistics...");
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT COUNT(*) AS totalPlayers, MAX(score1 + score2 + score3 + score4 + score5) AS highestScore FROM CompetitorDB";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int totalPlayers = rs.getInt("totalPlayers");
                int highestScore = rs.getInt("highestScore");
                System.out.println("Total Players: " + totalPlayers);
                System.out.println("Highest Score: " + highestScore);
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void searchCompetitorById(Scanner scanner) {
        System.out.print("Enter Competitor ID: ");
        int id = scanner.nextInt();
        // Logic to search for a competitor by ID
        System.out.println("Searching for competitor with ID: " + id);
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT * FROM CompetitorDB WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String username = rs.getString("username");
                String level = rs.getString("level");
                int score1 = rs.getInt("score1");
                int score2 = rs.getInt("score2");
                int score3 = rs.getInt("score3");
                int score4 = rs.getInt("score4");
                int score5 = rs.getInt("score5");
                System.out.println("Competitor found: ID: " + id + ", Username: " + username + ", Level: " + level +
                        ", Scores: [" + score1 + ", " + score2 + ", " + score3 + ", " + score4 + ", " + score5 + "]");
            } else {
                System.out.println("Competitor not found.");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}