package try1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminPanel {
    private JFrame frame;
    private JTextField questionField;
    private JTextField correctAnswerField;
    private JTextField option1Field;
    private JTextField option2Field;
    private JTextField option3Field;
    private JComboBox<String> questionComboBox;
    private JRadioButton beginnerRadioButton;
    private JRadioButton intermediateRadioButton;
    private JRadioButton advancedRadioButton;
    private ButtonGroup levelGroup;

    public AdminPanel() {
        frame = new JFrame("Admin Panel");
        frame.setSize(400, 450);
        frame.getContentPane().setBackground(new Color(0, 0, 160)); // Jet Black
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel questionLabel = new JLabel("Question:");
        questionLabel.setBounds(10, 20, 80, 25);
        questionLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.getContentPane().add(questionLabel);

        questionField = new JTextField();
        questionField.setBounds(100, 20, 250, 25);
        frame.getContentPane().add(questionField);

        JLabel correctAnswerLabel = new JLabel("Correct Answer:");
        correctAnswerLabel.setBounds(10, 60, 100, 25);
        correctAnswerLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.getContentPane().add(correctAnswerLabel);

        correctAnswerField = new JTextField();
        correctAnswerField.setBounds(120, 60, 230, 25);
        frame.getContentPane().add(correctAnswerField);

        JLabel option1Label = new JLabel("Option 1:");
        option1Label.setBounds(10, 100, 80, 25);
        option1Label.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.getContentPane().add(option1Label);

        option1Field = new JTextField();
        option1Field.setBounds(100, 100, 250, 25);
        frame.getContentPane().add(option1Field);

        JLabel option2Label = new JLabel("Option 2:");
        option2Label.setBounds(10, 140, 80, 25);
        option2Label.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.getContentPane().add(option2Label);

        option2Field = new JTextField();
        option2Field.setBounds(100, 140, 250, 25);
        frame.getContentPane().add(option2Field);

        JLabel option3Label = new JLabel("Option 3:");
        option3Label.setBounds(10, 180, 80, 25);
        option3Label.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.getContentPane().add(option3Label);

        option3Field = new JTextField();
        option3Field.setBounds(100, 180, 250, 25);
        frame.getContentPane().add(option3Field);

        // Radio buttons for difficulty level
        beginnerRadioButton = new JRadioButton("Beginner");
        beginnerRadioButton.setBounds(10, 220, 100, 25);
        beginnerRadioButton.setForeground(Color.decode("#E0E0E0"));
        beginnerRadioButton.setBackground(Color.decode("#121212"));
        beginnerRadioButton.setSelected(true); // Default selection
        frame.getContentPane().add(beginnerRadioButton);

        intermediateRadioButton = new JRadioButton("Intermediate");
        intermediateRadioButton.setBounds(120, 220, 120, 25);
        intermediateRadioButton.setForeground(Color.decode("#E0E0E0"));
        intermediateRadioButton.setBackground(Color.decode("#121212"));
        frame.getContentPane().add(intermediateRadioButton);

        advancedRadioButton = new JRadioButton("Advanced");
        advancedRadioButton.setBounds(250, 220, 100, 25);
        advancedRadioButton.setForeground(Color.decode("#E0E0E0"));
        advancedRadioButton.setBackground(Color.decode("#121212"));
        frame.getContentPane().add(advancedRadioButton);

        // Grouping radio buttons
        levelGroup = new ButtonGroup();
        levelGroup.add(beginnerRadioButton);
        levelGroup.add(intermediateRadioButton);
        levelGroup.add(advancedRadioButton);

        // ComboBox for selecting existing questions
        questionComboBox = new JComboBox<>();
        questionComboBox.setBounds(10, 260, 340, 25);
        frame.getContentPane().add(questionComboBox);
        loadQuestionsIntoComboBox();

        JButton addButton = new JButton("Add Question");
        addButton.setBounds(10, 300, 150, 25);
        addButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        addButton.setForeground(Color.WHITE);
        frame.getContentPane().add(addButton);

        JButton updateButton = new JButton("Update Question");
        updateButton.setBounds(170, 300, 150, 25);
        updateButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        updateButton.setForeground(Color.WHITE);
        frame.getContentPane().add(updateButton);

        JButton deleteButton = new JButton("Delete Question");
        deleteButton.setBounds(10, 340, 150, 25);
        deleteButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        deleteButton.setForeground(Color.WHITE);
        frame.getContentPane().add(deleteButton);

        // Logout Button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(170, 340, 150, 25);
        logoutButton.setBackground(Color.decode("#FF3B30")); // Crimson Red
        logoutButton.setForeground(Color.WHITE);
        frame.getContentPane().add(logoutButton);

        // Action Listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String question = questionField.getText();
                String correctAnswer = correctAnswerField.getText();
                String option1 = option1Field.getText();
                String option2 = option2Field.getText();
                String option3 = option3Field.getText();
                String difficulty = getSelectedDifficulty();

                if (question.isEmpty() || correctAnswer.isEmpty() || option1.isEmpty() || option2.isEmpty() || option3.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    addQuestionToDatabase(question, correctAnswer, option1, option2, option3, difficulty);
                }
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedQuestion = (String) questionComboBox.getSelectedItem();
                if (selectedQuestion != null) {
                    String question = questionField.getText();
                    String correctAnswer = correctAnswerField.getText();
                    String option1 = option1Field.getText();
                    String option2 = option2Field.getText();
                    String option3 = option3Field.getText();
                    String difficulty = getSelectedDifficulty();

                    if (question.isEmpty() || correctAnswer.isEmpty() || option1.isEmpty() || option2.isEmpty() || option3.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        updateQuestionInDatabase(selectedQuestion, question, correctAnswer, option1, option2, option3, difficulty);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a question to update.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedQuestion = (String) questionComboBox.getSelectedItem();
                if (selectedQuestion != null) {
                    deleteQuestionFromDatabase(selectedQuestion);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a question to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the admin panel
                new Login(); // Open the login screen
            }
        });

        frame.setVisible(true);
    }

    private void loadQuestionsIntoComboBox() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT question FROM questions";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                questionComboBox.addItem(rs.getString("question"));
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addQuestionToDatabase(String question, String correctAnswer, String option1, String option2, String option3, String difficulty) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "INSERT INTO questions (question, correct_answer, option1, option2, option3, difficulty) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, question);
            pstmt.setString(2, correctAnswer);
            pstmt.setString(3, option1);
            pstmt.setString(4, option2);
            pstmt.setString(5, option3);
            pstmt.setString(6, difficulty);
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(frame, "Question added successfully!");
            clearFields();
            questionComboBox.addItem(question); // Add new question to combo box
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding question to database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateQuestionInDatabase(String selectedQuestion, String question, String correctAnswer, String option1, String option2, String option3, String difficulty) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "UPDATE questions SET question = ?, correct_answer = ?, option1 = ?, option2 = ?, option3 = ?, difficulty = ? WHERE question = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, question);
            pstmt.setString(2, correctAnswer);
            pstmt.setString(3, option1);
            pstmt.setString(4, option2);
            pstmt.setString(5, option3);
            pstmt.setString(6, difficulty);
            pstmt.setString(7, selectedQuestion);
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(frame, "Question updated successfully!");
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error updating question in database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteQuestionFromDatabase(String selectedQuestion) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "DELETE FROM questions WHERE question = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, selectedQuestion);
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(frame, "Question deleted successfully!");
            questionComboBox.removeItem(selectedQuestion); // Remove deleted question from combo box
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error deleting question from database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        questionField.setText("");
        correctAnswerField.setText("");
        option1Field.setText("");
        option2Field.setText("");
        option3Field.setText("");
        levelGroup.clearSelection(); // Clear selected radio button
        beginnerRadioButton.setSelected(true); // Reset to default
    }

    private String getSelectedDifficulty() {
        if (beginnerRadioButton.isSelected()) {
            return "Beginner";
        } else if (intermediateRadioButton.isSelected()) {
            return "Intermediate";
        } else {
            return "Advanced";
        }
    }

    public static void main(String[] args) {
        new AdminPanel();
    }
}