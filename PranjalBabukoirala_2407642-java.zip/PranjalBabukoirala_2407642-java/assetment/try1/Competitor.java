package try1;

public class Competitor {
    private int id; // Competitor's ID
    private String username; // Competitor's username
    private String level; // Competitor's level (e.g., Beginner, Intermediate, Advanced)
    private int[] scores; // Array to hold up to 5 scores
    private int scoreCount; // To track the number of scores stored

    // Constructor to initialize the Competitor with an ID, username, and level
    public Competitor(int id, String username, String level,int s1,int s2,int s3, int s4, int s5) {
        this.id = id;
        this.username = username;
        this.level = level;
        this.scores = new int[5];
        scores[0]=s1;
        scores[1]=s2;
        scores[2]=s3;
        scores[3]=s4;
        scores[4]=s5;
        this.scoreCount = 0; // Initialize score count
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Getter for username
    public String getUsername() {
        return username;
    }

    // Getter for level
    public String getLevel() {
        return level;
    }

    // Method to add a score
    public void addScore(int score) {
        if (scoreCount < scores.length) {
            scores[scoreCount] = score; // Add score if there's space
            scoreCount++;
        } else {
            // Shift scores to the left and add the new score at the end
            System.arraycopy(scores, 1, scores, 0, scores.length - 1);
            scores[scores.length - 1] = score; // Add new score at the end
        }
    }

    // Method to get competitor details
    public String getDetails() {
        StringBuilder details = new StringBuilder("Competitor ID: " + id + "\nUsername: " + username + "\nLevel: " + level + "\nScores: ");
        for (int score : scores) {
            details.append(score).append(" "); // Append each score
        }
        return details.toString();
    }

    // Method to get all scores
    public int[] getScores() {
        return scores; // Return the scores array
    }

    // Method to calculate overall score
    public int getOverallScore() {
        int totalScore = 0;
        for (int score : scores) {
            totalScore += score; // Sum all scores
        }
        return totalScore; // Return total score
    }

    // Method to generate a report for the competitor
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("Competitor Report\n");
        report.append("ID: ").append(id).append("\n");
        report.append("Username: ").append(username).append("\n");
        report.append("Level: ").append(level).append("\n");
        report.append("Scores: ");
        for (int score : scores) {
            report.append(score).append(" "); // Append each score
        }
        report.append("\nOverall Score: ").append(getOverallScore()).append("\n");
        return report.toString();
    }
}