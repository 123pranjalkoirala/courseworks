package try1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SignUp {
    private JFrame frame;
    private JTextField usernameField;
    private JComboBox<String> levelComboBox; // ComboBox for selecting level

    public SignUp() {
        frame = new JFrame("Sign Up");
        frame.setSize(400, 300);
        frame.getContentPane().setBackground(Color.decode("#121212")); // Jet Black
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(10, 20, 80, 25);
        usernameLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(100, 20, 250, 25);
        frame.add(usernameField);

        JLabel levelLabel = new JLabel("Level:");
        levelLabel.setBounds(10, 60, 80, 25);
        levelLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.add(levelLabel);

        String[] levels = {"Beginner", "Intermediate", "Advanced"};
        levelComboBox = new JComboBox<>(levels);
        levelComboBox.setBounds(100, 60, 250, 25);
        frame.add(levelComboBox);

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(10, 100, 150, 25);
        signUpButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        signUpButton.setForeground(Color.WHITE);
        frame.add(signUpButton);

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String level = (String) levelComboBox.getSelectedItem(); // Get selected level

                if (username.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter a username.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    registerUser (username, level);
                }
            }
        });

        frame.setVisible(true);
    }

    private void registerUser (String username, String level) {
        if (isUsernameLevelExists(username, level)) {
            JOptionPane.showMessageDialog(frame, "This username is already registered with the selected level.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit the method if the username-level combination exists
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "INSERT INTO CompetitorDB (username, level, score1, score2, score3, score4, score5) VALUES (?, ?, NULL, NULL, NULL, NULL, NULL)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, level); // Set the level
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(frame, "User  registered successfully!");
            frame.dispose(); // Close the sign-up window
            new Login(); // Redirect to login screen after signing up
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error registering user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isUsernameLevelExists(String username, String level) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT * FROM CompetitorDB WHERE username = ? AND level = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, level);
            ResultSet rs = pstmt.executeQuery();

            boolean exists = rs.next(); // Check if a record exists
            conn.close();
            return exists;
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Default to false if there was an error
        }
    }

    public static void main(String[] args) {
        new SignUp();
    }
}