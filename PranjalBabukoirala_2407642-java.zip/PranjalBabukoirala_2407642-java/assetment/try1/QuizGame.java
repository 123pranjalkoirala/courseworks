package try1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;

public class QuizGame {
	private JFrame frame;
    private String username;
    private String level;
    private int score = 0;
    private int questionCount = 0;
    private int roundCount = 0; // Track the number of rounds completed
    private ArrayList<Question> questions;

    public QuizGame(String username, String level) {
        this.username = username;
        this.level = level;

        // Check if the competitor has already completed 5 rounds
        if (hasCompletedAllRounds(username,level)) {
            JOptionPane.showMessageDialog(null, "You have completed all 5 rounds. You cannot start a new quiz.", "Quiz Finished", JOptionPane.WARNING_MESSAGE);
            new MainDashboard(username, level); // Redirect to MainDashboard
            return; // Exit the constructor to prevent starting the quiz
        }
     // Load questions for the first round
        loadNewQuestions();

        // Check if there are no questions available
        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No questions available for the selected difficulty level.", "No Questions Available", JOptionPane.INFORMATION_MESSAGE);
            new MainDashboard(username, level); // Redirect to MainDashboard
            return; // Exit the constructor
        }

        frame = new JFrame("Quiz Game");
        frame.setSize(600, 400);
        frame.getContentPane().setBackground(Color.decode("#121212")); // Jet Black
        frame.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome, " + username + "!", SwingConstants.CENTER);
        welcomeLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        frame.add(welcomeLabel, BorderLayout.NORTH);

        loadNewQuestions(); // Load questions for the first round

        displayQuestion();

        frame.setVisible(true);
    }

    private boolean hasCompletedAllRounds(String username,String level) {
        // Logic to check if the competitor has completed all 5 rounds
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT COUNT(*) AS filledScores FROM CompetitorDB WHERE username = ? and level = ? AND (score1 IS NOT NULL AND score2 IS NOT NULL AND score3 IS NOT NULL AND score4 IS NOT NULL AND score5 IS NOT NULL)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, level);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int filledScores = rs.getInt("filledScores");
                return filledScores >= 1; // Return true if all 5 scores are filled
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Default to false if there was an error
    }
    private void loadNewQuestions() {
        questions = loadQuestions(level,username); // Load questions based on level
        Collections.shuffle(questions); // Shuffle questions
        questions = new ArrayList<>(questions.subList(0, Math.min(5, questions.size()))); // Limit to 10 questions
        questionCount = 0; // Reset question count for the new round
        score = 0; // Reset score for the new round
        roundCount++; // Increment the round count
    }

    private void displayQuestion() {
        if (questionCount < questions.size()) {
            Question question = questions.get(questionCount);
            JPanel questionPanel = new JPanel();
            questionPanel.setBackground(Color.decode("#1E1E1E")); // Charcoal Gray
            questionPanel.setLayout(new BoxLayout(questionPanel, BoxLayout.Y_AXIS));

            JLabel questionLabel = new JLabel(question.getQuestion());
            questionLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
            questionPanel.add(questionLabel);

            ButtonGroup group = new ButtonGroup();
            ArrayList<String> options = question.getOptions();
            options.add(question.getCorrectAnswer()); // Ensure the correct answer is included in the options
            Collections.shuffle(options); // Shuffle options to randomize their order

            for (String option : options) {
                JRadioButton optionButton = new JRadioButton(option);
                optionButton.setForeground(Color.decode("#E0E0E0")); // Platinum White
                optionButton.setBackground(Color.decode("#1E1E1E")); // Charcoal Gray
                group.add(optionButton);
                questionPanel.add(optionButton);
            }

            JButton nextButton = new JButton("Next");
            nextButton.setBackground(Color.decode("#007BFF")); // Electric Blue
            nextButton.setForeground(Color.WHITE);
            nextButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    for (AbstractButton button : Collections.list(group.getElements())) {
                        if (button.isSelected()) {
                            if (button.getText().equals(question.getCorrectAnswer())) {
                                score++;
                            }
                            questionCount++;
                            frame.getContentPane().removeAll();
                            displayQuestion();
                            frame.revalidate();
                            frame.repaint();
                            return;
                        }
                    }
                    JOptionPane.showMessageDialog(frame, "Please select an answer before proceeding.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            questionPanel.add(nextButton);
            frame.add(questionPanel, BorderLayout.CENTER);
        } else {
            finishQuiz();
        }
    }

    private void finishQuiz() {
        saveScoreToDatabase(score);
        if (roundCount < 5) {
            int response = JOptionPane.showConfirmDialog(frame, "Round " + roundCount + " completed! Your score: " + score + ". Do you want to take the next quiz?", "Quiz Finished", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                loadNewQuestions(); // Load new questions for the next round
                displayQuestion();
            } else {
                frame.dispose(); // Close the quiz frame
                redirectToMainDashboard(); // Redirect to MainDashboard
            }
        } else {
            // Show report after 5 rounds
            JOptionPane.showMessageDialog(frame, "You have completed all rounds. Your final score: " + score, "Quiz Finished", JOptionPane.INFORMATION_MESSAGE);
            frame.dispose(); // Close the quiz frame
            redirectToMainDashboard(); // Redirect to MainDashboard
        }
    }

    private void redirectToMainDashboard() {
        // Logic to redirect to the MainDashboard
        new MainDashboard(username, level); // Assuming MainDashboard requires username and level
    }

    private void saveScoreToDatabase(int score) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT score1, score2, score3, score4, score5 FROM CompetitorDB WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Get current scores
                Integer[] scores = new Integer[5];
                for (int i = 0; i < 5; i++) {
                    scores[i] = rs.getObject("score" + (i + 1), Integer.class); // Get scores as Integer (can be NULL)
                }

                // Update the first NULL score slot
                for (int i = 0; i < 5; i++) {
                    if (scores[i] == null) { // Check for NULL
                        String updateSql = "UPDATE CompetitorDB SET score" + (i + 1) + " = ? WHERE username = ?";
                        PreparedStatement updatePstmt = conn.prepareStatement(updateSql);
                        updatePstmt.setInt(1, score);
                        updatePstmt.setString(2, username);
                        updatePstmt.executeUpdate();
                        break;
                    }
                }
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private ArrayList<Question> loadQuestions(String level,String username) {
        ArrayList<Question> questionList = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            // Update the SQL query to select questions based on the level
            String sql = "SELECT question, correct_answer, option1, option2, option3 FROM questions WHERE difficulty = ? ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, level);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String questionText = rs.getString("question");
                String correctAnswer = rs.getString("correct_answer");
                ArrayList<String> options = new ArrayList<>();
                options.add(rs.getString("option1"));
                options.add(rs.getString("option2"));
                options.add(rs.getString("option3"));
                questionList.add(new Question(questionText, correctAnswer, options, level));
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questionList;
    }
}
