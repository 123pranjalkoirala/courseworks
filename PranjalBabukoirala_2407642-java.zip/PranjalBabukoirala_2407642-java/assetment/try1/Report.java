package try1;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Report {
    private JFrame frame;

    public Report(int score) {
        frame = new JFrame("Quiz Report");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel scoreLabel = new JLabel("Your Score: " + score);
        scoreLabel.setBounds(10, 20, 200, 25);
        frame.add(scoreLabel);

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(10, 80, 80 , 25);
        frame.add(closeButton);

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }
}