package try1;

import java.util.ArrayList;

/**
 * The {@code CompetitorList} class manages a list of competitors.
 * It provides functionality to add, retrieve, and display competitors.
 */
public class CompetitorList {
    private ArrayList<Competitor> competitors;

    /**
     * Constructs an empty list of competitors.
     */
    public CompetitorList() {
        competitors = new ArrayList<>();
    }

    /**
     * Adds a competitor to the list.
     *
     * @param competitor the competitor to be added
     */
    public void addCompetitor(Competitor competitor) {
        competitors.add(competitor);
    }

    /**
     * Retrieves a competitor from the list based on username and level.
     *
     * @param username the username of the competitor
     * @param level the level of the competitor
     * @return the competitor if found, otherwise {@code null}
     */
    public Competitor getCompetitor(String username, String level) {
        for (Competitor competitor : competitors) {
            if (competitor.getUsername().equals(username) && competitor.getLevel().equals(level)) {
                return competitor;
            }
        }
        return null; // Competitor not found
    }

    /**
     * Displays details of all competitors in the list.
     */
    public void displayAllCompetitors() {
        for (Competitor competitor : competitors) {
            System.out.println(competitor.getDetails());
        }
    }
}
