package try1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> levelComboBox;

    public Login() {
        frame = new JFrame("Login");
        frame.setSize(400, 400);
        frame.getContentPane().setBackground(new Color(0, 0, 128)); // Jet Black
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Admin Login Section
        JPanel adminPanel = new JPanel();
        adminPanel.setBounds(20, 20, 350, 150);
        adminPanel.setBackground(Color.decode("#2A2A2A")); // Gunmetal Gray
        adminPanel.setLayout(null);
        adminPanel.setBorder(BorderFactory.createLineBorder(Color.decode("#3B3B3B"))); // Steel Gray

        JLabel adminLabel = new JLabel("Admin Login");
        adminLabel.setBounds(10, 10, 100, 25);
        adminLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        adminPanel.add(adminLabel);

        JLabel adminUsernameLabel = new JLabel("Username:");
        adminUsernameLabel.setBounds(10, 40, 80, 25);
        adminUsernameLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        adminPanel.add(adminUsernameLabel);

        JTextField adminUsernameField = new JTextField();
        adminUsernameField.setBounds(100, 40, 165, 25);
        adminPanel.add(adminUsernameField);

        JLabel adminPasswordLabel = new JLabel("Password:");
        adminPasswordLabel.setBounds(10, 70, 80, 25);
        adminPasswordLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        adminPanel.add(adminPasswordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(100, 70, 165, 25);
        adminPanel.add(passwordField);

        JButton adminLoginButton = new JButton("Login");
        adminLoginButton.setBounds(10, 110, 80, 25);
        adminLoginButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        adminLoginButton.setForeground(Color.WHITE);
        adminPanel.add(adminLoginButton);

        frame.getContentPane().add(adminPanel);

        // Competitor Login Section
        JPanel competitorPanel = new JPanel();
        competitorPanel.setBounds(20, 200, 350, 150);
        competitorPanel.setBackground(Color.decode("#2A2A2A")); // Gunmetal Gray
        competitorPanel.setLayout(null);
        competitorPanel.setBorder(BorderFactory.createLineBorder(Color.decode("#3B3B3B"))); // Steel Gray

        JLabel competitorLabel = new JLabel("Competitor Login");
        competitorLabel.setBounds(10, 10, 150, 25);
        competitorLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        competitorPanel.add(competitorLabel);

        JLabel competitorUsernameLabel = new JLabel("Username:");
        competitorUsernameLabel.setBounds(10, 40, 80, 25);
        competitorUsernameLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        competitorPanel.add(competitorUsernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(100, 40, 165, 25);
        competitorPanel.add(usernameField);

        JLabel levelLabel = new JLabel("Level:");
        levelLabel.setBounds(10, 70, 80, 25);
        levelLabel.setForeground(Color.decode("#E0E0E0")); // Platinum White
        competitorPanel.add(levelLabel);

        String[] levels = {"Beginner", "Intermediate", "Advanced"};
        levelComboBox = new JComboBox<>(levels);
        levelComboBox.setBounds(100, 70, 165, 25);
        competitorPanel.add(levelComboBox);

        JButton competitorLoginButton = new JButton("Login");
        competitorLoginButton.setBounds(10, 110, 80, 25);
        competitorLoginButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        competitorLoginButton.setForeground(Color.WHITE);
        competitorPanel.add(competitorLoginButton);

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(100, 110, 80, 25);
        signUpButton.setBackground(Color.decode("#007BFF")); // Electric Blue
        signUpButton.setForeground(Color.WHITE);
        competitorPanel.add(signUpButton);

        frame.getContentPane().add(competitorPanel);

        // Action Listeners
        adminLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String adminUsername = adminUsernameField.getText();
                String adminPassword = new String(passwordField.getPassword());

                if (adminUsername.equals("admin") && adminPassword.equals("adminpass")) {
                    new AdminPanel(); // Open admin panel directly for admin
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid admin credentials", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        competitorLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String level = (String) levelComboBox.getSelectedItem();

                if (username.isEmpty() || level == null) {
                    JOptionPane.showMessageDialog(frame, "Please enter a username and select a level.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    if (validateCompetitor(username, level)) {
                        new MainDashboard(username, level); // Open the main dashboard
                        frame.dispose(); // Close the login frame
                    } else {
                        JOptionPane.showMessageDialog(frame, "Invalid username or level.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignUp(); // Open sign-up screen
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    private boolean validateCompetitor(String username, String level) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT * FROM CompetitorDB WHERE username = ? AND level = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, level);
            ResultSet rs = pstmt.executeQuery();

            boolean isValid = rs.next(); // Check if a record exists
            conn.close();
            return isValid;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}