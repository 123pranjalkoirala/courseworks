package try1;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class Dashboard {
    private JFrame frame;

    public Dashboard() {
        frame = new JFrame("Dashboard");
        frame.getContentPane().setBackground(new Color(0, 0, 160));
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JButton adminButton = new JButton("Admin Panel");
        adminButton.setBounds(50, 50, 200, 30);
        frame.getContentPane().add(adminButton);

        JButton playerButton = new JButton("Play Quiz");
        playerButton.setBounds(50, 100, 200, 30);
        frame.getContentPane().add(playerButton);

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminPanel(); // Open admin panel
            }
        });

        playerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new QuizGame("Player", "Beginner"); // Start quiz game for player
            }
        });

        frame.setVisible(true);
    }
}