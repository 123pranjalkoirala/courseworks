package try1;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Leaderboard {
    public Leaderboard() {
        // Create the leaderboard frame
        JFrame leaderboardFrame = new JFrame("Leaderboard");
        leaderboardFrame.setSize(400, 300);
        leaderboardFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close the frame when done
        leaderboardFrame.getContentPane().setLayout(new BorderLayout());

        // Create a text area to display the leaderboard
        JTextArea leaderboardArea = new JTextArea();
        leaderboardArea.setEditable(false);
        leaderboardArea.setBackground(new Color(0, 0, 0)); // Charcoal Gray
        leaderboardArea.setForeground(Color.decode("#E0E0E0")); // Platinum White

        // Load the leaderboard data
        StringBuilder scoreboard = new StringBuilder("Top 10 Average High Scorers:\n");
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb", "root", "");
            String sql = "SELECT username, level, " +
                         "(COALESCE(score1, 0) + COALESCE(score2, 0) + COALESCE(score3, 0) + COALESCE(score4, 0) + COALESCE(score5, 0)) AS total ," +
                         "((COALESCE(score1, 0) + COALESCE(score2, 0) + COALESCE(score3, 0) + COALESCE(score4, 0) + COALESCE(score5, 0)) / " +
                         "CASE WHEN (score1 + score2 + score3 + score4 + score5) = 0 THEN 1 ELSE 5 END) AS avg_score " +
                         "FROM CompetitorDB " +
                         "ORDER BY avg_score DESC LIMIT 10";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String user = rs.getString("username");
                String userLevel = rs.getString("level");
                int totalScore = rs.getInt("total");
                double avgScore = rs.getDouble("avg_score");
                scoreboard.append("Username: ").append(user)
                          .append(", Level: ").append(userLevel)
                          .append(", Total Score: ").append(totalScore)
                          .append(", Average Score: ").append(String.format("%.2f", avgScore)).append("\n");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Set the text area with the scoreboard data
        leaderboardArea.setText(scoreboard.toString());
        leaderboardFrame.getContentPane().add(new JScrollPane(leaderboardArea), BorderLayout.CENTER); // Add scroll pane for the text area

        // Make the frame visible
        leaderboardFrame.setVisible(true);
    }
}