package try1;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Statistics {
    private JFrame frame;

    public Statistics() {
        frame = new JFrame("Statistics");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JButton viewStatsButton = new JButton("View Statistics");
        viewStatsButton.setBounds(50, 50, 200, 30);
        frame.add(viewStatsButton);

        viewStatsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Fetch and display statistics (placeholder)
                JOptionPane.showMessageDialog(frame, "Total Players: 100\nHighest Score: 95");
            }
        });

        frame.setVisible(true);
    }
}