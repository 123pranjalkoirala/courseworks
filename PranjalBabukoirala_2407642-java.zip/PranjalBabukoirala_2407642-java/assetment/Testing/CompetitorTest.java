package Testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import try1.Competitor;

public class CompetitorTest {
    private Competitor competitor;

    @BeforeEach
    public void setUp() {
        competitor = new Competitor(1, "testUser ", "Beginner", 10, 20, 30, 40, 50);
    }

    @Test
    public void testGetId() {
        assertEquals(1, competitor.getId());
    }

    @Test
    public void testGetUsername() {
        assertEquals("testUser ", competitor.getUsername());
    }

    @Test
    public void testGetLevel() {
        assertEquals("Beginner", competitor.getLevel());
    }


    @Test
    public void testGetOverallScore() {
        assertEquals(150, competitor.getOverallScore()); // 10 + 20 + 30 + 40 + 50
    }

}

