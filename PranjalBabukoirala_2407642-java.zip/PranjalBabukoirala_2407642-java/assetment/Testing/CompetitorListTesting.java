package Testing;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import try1.Competitor;
import try1.CompetitorList;

public class CompetitorListTesting {
    private CompetitorList competitorList;

    @BeforeEach
    public void setUp() {
        competitorList = new CompetitorList();
        competitorList.addCompetitor(new Competitor(1, "testUser 1", "Beginner", 10, 20, 30, 40, 50));
        competitorList.addCompetitor(new Competitor(2, "testUser 2", "Intermediate", 15, 25, 35, 45, 55));
    }

    @Test
    public void testGetCompetitor() {
        Competitor competitor = competitorList.getCompetitor("testUser 1", "Beginner");
        assertNotNull(competitor);
        assertEquals("testUser 1", competitor.getUsername());
    }

    @Test
    public void testDisplayAllCompetitors() {
        // This method prints to console, so we can only check if it runs without exceptions
        competitorList.displayAllCompetitors();
    }
}